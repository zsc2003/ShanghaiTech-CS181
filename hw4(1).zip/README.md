# CS182 HW4

## Introduction

HW4 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (60 PTS)

1. Finish the problems in `writing/hw4.pdf`.
2. Upload your answers as "yourname_hw4_writing.pdf" to Gradescope.

### Part Two: Coding (40 PTS)

1. Finish `coding/svm.ipynb`. 
2. Please export the jupyter notebook as a PDF named  "yourname_hw4_coding.pdf" and upload it to Gradescope.

## Due date

Tuesday Dec.19 at 11:59pm (CST)